""" package to read a Zemax .zmx file and produce a rayoptics OpticalModel
"""
