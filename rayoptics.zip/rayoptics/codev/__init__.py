""" package to read a CODE V sequence file and produce a rayoptics OpticalModel
"""
